const math=require('./practice');
a=math.add(5,8);
b=math.sub(100,56);
console.log(a)
console.log(b)
console.log(math('Meetha'));
console.log(math('This is Sanjay'));